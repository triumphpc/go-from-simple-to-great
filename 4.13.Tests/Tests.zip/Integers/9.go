//
// Go (Golang) From simple to great. The Complete Developer's Guide.
//
// 1. Choose the optimal type for an values from -12 to 25
//
// @author Alex Versus 2021
// www.alexversus.com
//

package main

import "fmt"

func main() {
	var d int8 = -12
	fmt.Printf("%T (%[1]v)", d)
}
