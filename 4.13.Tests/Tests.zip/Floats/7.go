//
// Go (Golang) From simple to great. The Complete Developer's Guide.
//
// 1. Choose optimal type for 36.6 number
//
// @author Alex Versus 2021
//

package main

import "fmt"

func main() {
	var x float32 = 36.6

	fmt.Printf("%T (%[1]v)", x)

}
